<?php

// Define DB Params
define("DB_HOST", "subwaytalent-new-instance.cynjmepbcwub.us-east-1.rds.amazonaws.com");
define("DB_USER", "subwayuser");
define("DB_PASS", "subwayuser1");
define("DB_NAME", "subwaytalent-prod");

// Google Maps API key
define("GOOGLE_API_MAPS", "AIzaSyDMbNqkyC1lxuGWJddkNq5cyBAS_IiRFCY");

// Define URL
define("ROOT_PATH", "/nazz_admin/");
define("ROOT_URL", "/nazz_admin/");